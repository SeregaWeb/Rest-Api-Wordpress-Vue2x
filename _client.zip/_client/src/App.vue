<template>
  <div id="app">
    <Header :logo="array_data.logo" :phone="array_data.phone_number"></Header>
    <main>
      <router-view />
    </main>
    <Footer :logo="array_data.logo" :copyright="array_data.copyright"></Footer>
  </div>
</template>
<script>
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
export default {
  components: {
    Header,
    Footer
  },
  data() {
    return {
      array_data: {
        logo: {
          url: ""
        }
      }
    };
  },
  mounted() {
    fetch("http://localhost:8888/Vue_wordpress/server/wp-json/spa/v1/start/")
      .then(r => r.json())
      .then(res => (this.array_data = res));
  }
};
</script>

<style>
* {
  padding: 0;
  margin: 0;
}
main {
  flex: 1;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  max-width: 1360px;
  margin: 0 auto;
}
</style>
