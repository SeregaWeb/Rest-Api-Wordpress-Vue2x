<template>
  <header class="header">
    <div class="header-logo">
      <img :src="logo.url" alt="logo" />
    </div>
    <div class="header-nav">
      <div id="nav">
        <router-link to="/">Home</router-link> |
        <router-link to="/about">About</router-link>
      </div>
      <a href="tel:">{{ phone }}</a>
    </div>
  </header>
</template>
<script>
export default {
  name: "Header",
  props: {
    logo: Object,
    phone: String
  }
};
</script>

<style lang="scss" scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  &-logo {
    img {
      width: 100px;
      height: 100px;
    }
  }
  a {
    text-decoration: none;
    color: #000;
  }
  &-nav {
    display: flex;
  }
  #nav {
    padding: 0 30px;
    a {
      font-weight: bold;
      color: #2c3e50;
      &.router-link-exact-active {
        color: #42b983;
      }
    }
  }
}
</style>
