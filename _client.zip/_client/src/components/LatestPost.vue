<template>
  <div v-if="!loading" class="latest-post">
    <div v-for="post in posts" class="card" :key="post.id" :id="post.id">
      <a href="#" class="card-link js-card-link">
        <img :src="post.image" alt="post" />
      </a>
      <router-link class="card-link" :to="/Single/ + post.id">
        <h4 class="card-title">{{ post.title }}</h4>
      </router-link>
      <span class="card-date">{{ post.date }}</span>
      <p class="card-description">{{ post.subtitle }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "LatestPost",
  data() {
    return {
      loading: false,
      posts: []
    };
  },
  mounted() {
    this.loading = true;
    fetch("http://localhost:8888/Vue_wordpress/server/wp-json/spa/v1/post")
      .then(r => r.json())
      .then(res => {
        let new_object = {};
        for (let i = 0; i < res.length; i++) {
          new_object = {
            id: res[i].ID,
            date: res[i].post_date,
            title: res[i].post_title,
            subtitle: res[i].acf.post_text,
            image: res[i].acf.post_image.url
          };
          this.posts.push(new_object);
        }
        console.log(this.posts);
        this.loading = false;
      });
  }
};
</script>

<style lang="scss" scoped>
.latest-post {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  .card {
    width: 33%;
    &-link {
      text-decoration: none;
      color: #333d53;
    }
    &-description {
      font-size: 14px;
    }
    &-date {
      font-size: 12px;
    }
    &-title {
      font-size: 26px;
    }
    img {
      max-width: 100%;
      width: 100%;
      height: 200px;
      object-fit: cover;
      object-position: center;
    }
  }
}
</style>
