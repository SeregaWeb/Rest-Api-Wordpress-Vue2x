<template>
  <div class="title">
    <h2>{{ msg }}</h2>
  </div>
</template>

<script>
export default {
  name: "Title",
  props: {
    msg: String
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
h2 {
  font-size: 40px;
  text-align: left;
  font-family: sans-serif;
  line-height: 1.5;
  &:before {
    content: "-";
    font-size: 50px;
    padding-right: 20px;
  }
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
