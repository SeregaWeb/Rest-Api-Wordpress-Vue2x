<template>
  <footer class="footer">
    <div class="footer-logo">
      <img :src="logo.url" alt="logo" />
    </div>
    <div class="footer-nav">
      <p>© {{ copyright }}</p>
    </div>
  </footer>
</template>
<script>
export default {
  name: "Header",
  props: {
    logo: Object,
    copyright: String
  }
};
</script>

<style lang="scss" scoped>
.footer {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  &-logo {
    img {
      width: 100px;
      height: 100px;
    }
  }
  a {
    text-decoration: none;
    color: #000;
  }
}
</style>
