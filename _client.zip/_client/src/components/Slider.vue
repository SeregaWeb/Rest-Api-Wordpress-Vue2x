<template>
  <swiper :options="swiperOption">
    <swiper-slide v-for="(slide, index) in swiperSlides" :key="index">
      <img :src="slide.image.url" alt="slide" />
      <div class="swiper-info">
        <h3>{{ slide.title }}</h3>
        <p>{{ slide.text }}</p>
      </div>
    </swiper-slide>
    <div class="swiper-button-prev" slot="button-prev"></div>
    <div class="swiper-button-next" slot="button-next"></div>
    <div class="swiper-pagination" slot="pagination"></div>
  </swiper>
</template>

<script>
import "swiper/dist/css/swiper.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  name: "Slider",
  data() {
    return {
      swiperOption: {
        pagination: {
          el: ".swiper-pagination"
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        }
      },
      swiperSlides: {}
    };
  },
  components: {
    swiper,
    swiperSlide
  },
  mounted() {
    fetch("http://localhost:8888/Vue_wordpress/server/wp-json/spa/v1/slider/", {
      method: "POST",
      body: JSON.stringify({
        page: "Home"
      })
    })
      .then(r => r.json())
      .then(res => (this.swiperSlides = res));
  }
};
</script>

<style lang="scss" scoped>
img {
  width: 100%;
  height: 500px;
  object-fit: cover;
  object-position: center;
}
.swiper-info {
  position: absolute;
  top: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.5);
  padding: 20px;
  h3 {
    color: #fff;
    font-size: 30px;
    font-weight: bold;
  }
  p {
    color: #fff;
  }
}
</style>
