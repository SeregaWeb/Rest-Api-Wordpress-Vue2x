<template>
  <div class="home">
    <Title msg="Used technologies"></Title>
    <Slider></Slider>
    <Title msg="Latest publications"></Title>
    <LatestPost></LatestPost>
  </div>
</template>

<script>
import LatestPost from "@/components/LatestPost.vue";
import Title from "@/components/Title.vue";
import Slider from "@/components/Slider.vue";

export default {
  name: "Home",
  components: {
    LatestPost,
    Title,
    Slider
  }
};
</script>

<style lang="scss" scoped>
h1 {
  span {
    color: green;
  }
  color: red;
}
</style>
