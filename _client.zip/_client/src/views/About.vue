<template>
  <div class="about">
    <h1>This is an about page <span>red</span></h1>
  </div>
</template>
